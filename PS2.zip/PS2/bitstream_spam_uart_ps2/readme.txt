apenas faz o spam da tecla pressionada para a uart
